from .index import IndexResource
from .collection import CollectionResource

__all__ = ["IndexResource", "CollectionResource"]
